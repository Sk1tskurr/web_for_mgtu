
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Register.css'; // Подключите стили

const Register = () => {
    const [regLogin, setRegLogin] = useState('');
    const [regPassword, setRegPassword] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('/register_new_user', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ regLogin, regPassword }),
            });

            const result = await response.json();

            if (result.success) {
                alert('Регистрация прошла успешно');
                navigate('/login');
            } else {
                alert(result.message);
            }
        } catch (error) {
            console.error('Ошибка:', error);
        }
    };

    return (
        <div className="register-container">
            <h2>Регистрация</h2>
            <form onSubmit={handleSubmit}>
                <label htmlFor="regLogin">Логин:</label>
                <input
                    type="text"
                    id="regLogin"
                    value={regLogin}
                    onChange={(e) => setRegLogin(e.target.value)}
                    required
                />
                <label htmlFor="regPassword">Пароль:</label>
                <input
                    type="password"
                    id="regPassword"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    required
                />
                <button type="submit">Зарегистрироваться</button>
            </form>
        </div>
    );
};

export default Register;
